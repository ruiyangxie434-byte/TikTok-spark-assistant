# Mobile compatibility changes
Upstream: zhinjs/douyin-im, f6eee669c39094224e00c6b877e1964d9da4e393 (MIT).
Only the logger module is replaced with silent methods, and the node:sqlite import is disabled. All clients must pass localState:false. Authentication, signing, verification, IM transport and send implementations are unchanged. No upstream account/session files are included.

Strict UTF-8 decoding uses a byte-exact Buffer round trip in wire.js and frontier-cursors.js because Node Mobile has no ICU. Invalid encodings still throw; initial BOM is stripped.
